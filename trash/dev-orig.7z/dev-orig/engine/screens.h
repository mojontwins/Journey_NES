// MT MK2 NES v0.4
// Copyleft 2016 by The Mojon Twins

// Code for fixed screens

void enter_screen (const unsigned char *pal, void (*func) (void)) {
	//scroll (0, 0);
	
	cls ();
	reset_attributes ();
	
	pal_bg (pal);
	rdd = 1; (*func) ();
	if (rdd) show_attributes ();
	
	ppu_on_all ();
	fade_in ();
}

void exit_cleanly (void) {
	//set_vram_update (0);
	music_stop ();
	oam_hide_rest (0);
	fade_out ();
	ppu_off ();	
}

void wait_time_or_input (void) {
	rda = (pad_poll (0) != 0);
	while (game_time) {
		ticker ++; if (ticker == ticks) {
			ticker = 0;
			game_time --;
		}

		if (pad_poll (0)) {
			if (!rda) break;
		} else {
			rda = 0;
		}

		ppu_wait_nmi ();
	}
}

void do_screen (unsigned char seconds) {
	game_time = seconds; ticker = 0;
	wait_time_or_input ();
	exit_cleanly ();
}
/*
void twospr (unsigned char x, unsigned char y, const unsigned char *s1, const unsigned char *s2) {
	oam_hide_rest (oam_meta_spr (x, y, oam_meta_spr (x, y, 0, s1), s2));
}
*/
void screen_title (void) {
	if (egg) {
		//p_s (12, 12, " DESTROY THE EGGS%%IN THIS ALIEN CAVE%%%%   PRESS START!");
	} else {
		vram_adr (NAMETABLE_A);
		vram_unrle (napia_title_rle);
		p_s (10, 23, "PRESS START!");
		p_s (5, 25, "@ 2017 THE MOJON TWINS");
		rdd = 0;
	}
	
	//twospr (36, 68, ssti_01, ssti_00);		
	pal_spr (palss_1);
	oam_hide_rest (oam_meta_spr (160, 35, 0, sspl_00_b));
}

void screen_game_over (void) {
	p_s (11, 14, "GAME OVER!");
}

void screen_game_ending (void) {
	vram_adr (NAMETABLE_A);
	vram_unrle (napia_ending_rle);
	pal_spr (palss_1);
	//twospr (64, 84, sste_01, sste_00);
	rdd = 0;
}
