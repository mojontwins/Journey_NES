// MT MK2 NES v0.4
// Copyleft 2016 by The Mojon Twins

// Hud. Of course, this has to be customized for each game

void hud_update (void) {
	if (plife != oplife) p_t2 (6, 2, plife);
	if (pobjs != opobjs) p_t2 (18, 2, max_hotspots_type_1 - pobjs);
	if (pkeys != opkeys) p_t2 (29, 2, pkeys);
	opobjs = pobjs;
	opkeys = pkeys;
	oplife = plife;
}

void hud_draw (void) {
	vram_adr (NAMETABLE_A);
	vram_unrle (napia_hud_rle);
	p_s (1, 2, "LIFE:00  PENCILS:00  CUTTER:00");	
	if (egg) p_s (9, 2, "   EGG");
}
