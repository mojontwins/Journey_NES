// MT MK2 NES v0.4
// Copyleft 2016 by The Mojon Twins

// Game loop & shit

void game_init (void) {
	gp_gen = scr_attr + 192; gpit = 16; while (gpit --) *gp_gen = 0;

	c_ts_pals = l_ts_pals [level];
	c_ts_tmaps = l_ts_tmaps [level];
	c_behs = l_behs [level];
	n_pant = l_n_pant [level];
		
	c_map = l_map [level];
	c_enems = l_enems [level];
	c_hotspots = l_hotspots [level];
	c_locks = l_locks [level];

	spr_enems = l_spr_enems [level];

	// Fake constants for this cart...
	MAP_W = l_MAP_W [level];
	MAP_H = l_MAP_H [level];
	max_pant = l_max_pant [level];
	
	// All player constants are parametrized so we can have OOZE LEVELS!
	PLAYER_VX_MAX = l_PLAYER_VX_MAX [level]; 
	PLAYER_AX = l_PLAYER_AX [level];
	PLAYER_RX = l_PLAYER_RX [level];
	
	PLAYER_VY_JUMP_INITIAL = l_PLAYER_VY_JUMP_INITIAL [level];
	PLAYER_AY_JUMP = l_PLAYER_AY_JUMP [level];
	PLAYER_VY_JUMP_MAX = l_PLAYER_VY_JUMP_MAX [level];

	plife = 5;

	max_hotspots_type_1 = l_max_hotspots_type_1 [level];

#if defined(ENEMIES_CAN_DIE) && defined(PERSISTENT_DEATHS)
	enems_persistent_deaths_init ();
#endif	
#ifdef PERSISTENT_ENEMIES
	persistent_enems_load ();
#endif		

#ifdef HOTSPOT_TYPE_KEY
	bolts_load ();
#endif
	player_init ();
	hotspots_ini ();

	pal_bg ( l_pals_bg [level] );

	oplife = 0xff;
	pobjs = 0; opobjs = 0xff;
#ifdef HOTSPOT_TYPE_KEY
	pkeys = 0; opkeys = 0xff;
#endif
}

void game_prepare_screen (void) {
	if (first_time) first_time = 0; else fade_out ();
	ppu_off ();

	draw_scr ();

#ifdef ENABLE_FUMETTOS
	fumettos_init ();
#endif

	// Update bolts
#ifdef HOTSPOT_TYPE_KEY
	bolts_update_screen ();
#endif
	
#ifdef PLAYER_CAN_FIRE	
	bullets_ini ();
#endif
#ifdef SHOOTING_DRAINS	
	flower_ini ();
#endif
#ifdef PERSISTENT_ENEMIES
	persistent_update ();
#endif	
	enems_load ();
	hotspots_load ();

#ifdef SHOOTING_DRAINS		
	pgauge = 30; bullets_draw_gauge_offline ();
#endif
#ifdef ENABLE_COCOS	
	simplecoco_init ();
#endif

	ppu_on_all ();

	oam_index = 28;
	prx = px >> FIX_BITS; pry = py >> FIX_BITS;
	player_render ();
	hotspots_do ();
	enems_do ();

	oam_hide_rest (oam_index);
	ul = update_list; hud_update (); *ul = NT_UPD_EOF;
	ppu_wait_nmi ();

	fade_in ();
}

void game_loop (void) {
	girlact = 0;
	half_life = 0;
	first_time = 1;
	on_pant = 99;
	game_res = GS_GAME_OVER;

	reset_attributes ();

	ppu_on_all ();

#ifdef PLAYER_FLICKERS
	pflickering = PLAYER_FLICKERS;
#endif	

	music_play (MUSIC_INGAME);
	set_vram_update (update_list);

	do_game = 1; // ticker = ticks;
	pwashit = 0;

	while (do_game) {		
		half_life = 1 - half_life;		// Main flip-flop
		frame_counter ++;				// Increase frame counter
		//if (ticker) ticker --; else ticker = ticks;
	
		ul = update_list;				// Reset pointer to update list
		oam_index = 28;					// Reset OAM index; skip sprite #0 & player
		pad0 = pad_poll (0);			// Read pads here.

#ifdef PLAYER_CAN_FIRE
		bullets_do ();
#endif
		hotspots_do ();
		enems_do ();
#ifdef ENABLE_COCOS		
		simplecoco_do ();
#endif		
#ifdef SHOOTING_DRAINS			
		flower_do ();
#endif

		player_move ();	
		if (n_pant == on_pant) player_render ();
		if (pwashit) player_hit ();

		if (hrt && half_life) oam_index = oam_meta_spr (hrx, hry + SPRITE_ADJUST, oam_index, ssit_03);
		player_border ();

#ifdef ENABLE_FUMETTOS
		fumettos_do ();
#endif

		oam_hide_rest (oam_index);

		hud_update ();

		*ul = NT_UPD_EOF;
		ppu_wait_nmi ();

		if (pkilled || pobjs == max_hotspots_type_1) do_game = 0;

		#include "engine/mainloop/flick_screen.h"
	}

	set_vram_update (0);
	exit_cleanly ();
}

void game_title (void) {
	enter_screen (palts_title, screen_title);
	
	gpit = 0; while (!gpit) {
		if (pad_poll (0) & PAD_START) {
			level = 0;
			gpit = 1;
		}
		ppu_wait_nmi ();
	}
	while (pad_poll (0));
	
	music_stop ();
	sfx_play (SFX_START, SC_LEVEL);
	delay (ticks);

	exit_cleanly ();
}

void game_over (void) {
	enter_screen (palts_title, screen_game_over);
	music_play (MUSIC_GAME_OVER);
	do_screen (10);
}

void game_ending (void) {
	enter_screen (palts_title, screen_game_ending);
	music_play (MUSIC_TITLE);
	do_screen (255);
}
