// MT MK2 NES v0.4
// Copyleft 2016 by The Mojon Twins

#define STANDALONE	// Comment when assembling to main ROM.

// Shiru's

#include "neslib.h"

// Some needed stuff...

#include "definitions.h"

// Main const includes

#include "assets/palettes.h"
#include "assets/precalcs.h"
#include "assets/enems_1.h"
#include "assets/map_1.h"
#include "assets/tiledata3.h"
#include "assets/metasprites.h"
#include "assets/behs.h"
#include "assets/napia_hud_rle.h"
#include "assets/napia_title_rle.h"
#include "assets/napia_ending_rle.h"
#include "assets/levelset.h"

// Some variables

#pragma bss-name (push,"ZEROPAGE")
#pragma data-name(push,"ZEROPAGE")

#include "ram/zp.h"

#pragma bss-name (push,"BSS")
#pragma data-name(push,"BSS")

#include "ram/bss.h"

// Engine functions

#include "engine/printer.h"
#include "engine/screens.h"
#include "engine/general.h"
#ifdef SHOOTING_DRAINS
#include "engine/flower.h"
#endif
#ifdef PLAYER_CAN_FIRE
#include "engine/bullets.h"
#endif
#include "engine/hotspots.h"
#ifdef HOTSPOT_TYPE_KEY
#include "engine/bolts.h"
#endif
// CUSTOM {
#include "engine/fumettos.h"
// } END_OF_CUSTOM
#include "engine/player.h"
#ifdef ENABLE_COCOS
#include "engine/simplecoco.h"
#endif
#include "engine/enems.h"
#include "engine/hud.h"
#include "engine/mapper11.h"

#include "engine/game.h"

// Functions

void main (void) {
#ifndef STANDALONE
	m11_handle_reset ();		// If bad checksum, this jumps to PRG 0 / CHR 0 (main menu)
	egg = COMM_GAME_SELECT & 0x10;
#else
	//level = 1;
#endif	

	pal_spr ( palss_1 );

	bank_bg (0);
	bank_spr (1);
			
	ticks = ppu_system () ? 60 : 50;
	halfticks = ticks >> 1;
	c_alt_tile = 16;

	oam_size (0);
	pal_bright (0);

	scroll (0, SCROLL_Y);

	while (1) {
		game_title ();
		hud_draw ();
		game_init ();
		game_loop ();

		if (pkilled) {
			game_over ();
		} else {
			game_ending ();
		}
	}
}
