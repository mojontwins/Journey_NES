// MT MK2 NES v0.4
// Copyleft 2016 by The Mojon Twins

// Metaspriteset

#include "assets/spritedata3.h"

// Of course, you have to somewhat customize this for every game and make it fit.

// Rock the Kashbah
const unsigned char * const spr_enems_1 [] = {
	ssen_1_00_a, ssen_1_01_a, ssen_1_00_b, ssen_1_01_b, 
	ssen_1_02_a, ssen_1_03_a, ssen_1_02_b, ssen_1_03_b, 
	ssen_1_04_a, ssen_1_05_a, ssen_1_04_b, ssen_1_05_b, 
	ssmp_00, ssmp_01, ssmp_00, ssmp_01
};

// RIGHT, LEFT; IDLE, W1 W2 W3 W4, UP, DOWN
const unsigned char * const spr_player [] = {
	sspl_00_a, sspl_01_a, sspl_02_a, sspl_03_a, sspl_04_a, sspl_05_a, sspl_06_a, sspl_07_a, sspl_08_a, // RIGHT
	sspl_00_b, sspl_01_b, sspl_02_b, sspl_03_b, sspl_04_b, sspl_05_b, sspl_06_b, sspl_07_b, sspl_08_b, // LEFT

	// Reborde
	ssrb_00_a, ssrb_01_a, ssrb_02_a, ssrb_03_a, ssrb_04_a, ssrb_05_a, ssrb_06_a, ssrb_07_a, ssrb_08_a, // RIGHT
	ssrb_00_b, ssrb_01_b, ssrb_02_b, ssrb_03_b, ssrb_04_b, ssrb_05_b, ssrb_06_b, ssrb_07_b, ssrb_08_b // LEFT
};

// Items are: [nothing] object key refill
// The wasted space saves a bit of code
const unsigned char * const spr_items [] = {
	0, ssit_00, ssit_01, ssit_02, ssit_04
};

// FUCK

const unsigned char sprplempty [] = {
	-4, -8, 0, 0, 4, -8, 0, 0, 
	-4, 0, 0, 0, 4, 0, 0, 0, 
	-4, 8, 0, 0, 4, 8, 0, 0, 
	0x80
};
