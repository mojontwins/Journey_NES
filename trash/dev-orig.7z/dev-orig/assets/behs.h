// MT MK2 NES v0.4
// Copyleft 2016 by The Mojon Twins

// Tile behaviours

const unsigned char behs_0 [] = {
	0, 0, 0, 8, 8, 8, 0, 1, 1, 8, 8, 8, 4, 8, 0,10,
	0, 0, 0, 8, 8, 8, 0, 8, 8, 8, 8, 8, 8, 8, 0, 8	
};

const unsigned char behs_1 [] = {
	0, 0, 0, 8, 8, 8, 0, 1, 1, 8, 8, 8, 4, 8, 0,10,
	0, 0, 0, 8, 8, 8, 0, 8, 8, 8, 8, 8, 8, 8, 0, 8	
};

const unsigned char behs_2 [] = {
	0, 0, 0, 8, 8, 8, 0, 1, 1, 8, 8, 8, 4, 8, 0,10,
	0, 0, 0, 8, 8, 8, 0, 8, 8, 8, 8, 8, 8, 8, 0, 8	
};
